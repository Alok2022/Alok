from django.apps import AppConfig


class SubPartConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sub_part'
